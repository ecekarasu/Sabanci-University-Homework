package com.sabanciuniv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BsExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}

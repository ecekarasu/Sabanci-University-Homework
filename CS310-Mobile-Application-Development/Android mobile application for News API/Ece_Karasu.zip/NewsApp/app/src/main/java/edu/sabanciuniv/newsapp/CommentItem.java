package edu.sabanciuniv.newsapp;

public class CommentItem {

    private int id;
    private String name;
    private String msg;

    // default constructor
    public CommentItem() {
    }

    // constructor
    public CommentItem(int id,String name, String message) {
        this.name = name;
        this.msg = message;
        this.id = id;
    }

    // setters and getters
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getMessage() {
        return msg;
    }
    public void setMessage(String message) {
        this.msg = message;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

}

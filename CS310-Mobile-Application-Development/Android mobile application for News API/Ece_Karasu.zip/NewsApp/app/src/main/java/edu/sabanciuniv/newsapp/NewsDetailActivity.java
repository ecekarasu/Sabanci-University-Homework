package edu.sabanciuniv.newsapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;

public class NewsDetailActivity extends AppCompatActivity {

    ImageView imgNews; // news image to be displayed
    TextView txtDesc; // news description to be displayed
    TextView txtTitle; // news title to be displayed
    TextView txtDate; // news date to be displayed
    NewsItem selected; // news that is clicked

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_detail);
        imgNews = findViewById(R.id.imgnewsdetail);
        txtDesc = findViewById(R.id.txtnewsdesc);
        txtTitle = findViewById(R.id.txttitle);
        txtDate = findViewById(R.id.txtdate);

        selected = (NewsItem) getIntent().getSerializableExtra("selectednew");

        imgNews.setImageBitmap(selected.getBitmap());

        if(selected.getBitmap() == null){
            new ImageDownload(imgNews).execute(selected);
        }
        else{
            imgNews.setImageBitmap(selected.getBitmap());
        }

        txtDesc.setText(selected.getText());
        txtTitle.setText(selected.getTitle());
        txtDate.setText(new SimpleDateFormat("dd/MM/yyy").format(selected.getNewsDate()));

        getSupportActionBar().setTitle(selected.getCategory());
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        getSupportActionBar().setHomeAsUpIndicator(android.R.drawable.ic_media_previous);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if(item.getItemId()== R.id.mn_addcomment){
            // clicked news to pass to CommentActivity
            Intent i = new Intent(this, CommentActivity.class);
            i.putExtra("selectednewid", selected.getId());
            startActivity(i);
        }
        else if (item.getItemId() == android.R.id.home){
            onBackPressed();
        }
        return true;
    }

    // this class to download the news images
    class ImageDownload extends AsyncTask<NewsItem, Void, Bitmap> {

        ImageView imgView;

        public ImageDownload(ImageView imgView){
            this.imgView = imgView;
        }

        @Override
        protected Bitmap doInBackground(NewsItem... newsItems) {

            NewsItem current = newsItems[0];
            Bitmap bitmap = null;

            try {
                URL url = new URL(current.getImagePath());
                InputStream is = new BufferedInputStream(url.openStream());

                bitmap = BitmapFactory.decodeStream(is);
                current.setBitmap(bitmap);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {

            imgView.setImageBitmap(bitmap);
        }
    }
}



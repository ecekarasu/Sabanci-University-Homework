package edu.sabanciuniv.newsapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Objects;

public class PostCommentActivity extends AppCompatActivity {
    EditText name; // Your name to be posted
    TextView text; // Your comments to be posted
    String news_id; // news id that will have the comments

    ProgressDialog prgDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_comment);

        name = findViewById(R.id.txtname);
        text = findViewById(R.id.txtmessage);
        news_id = String.valueOf(getIntent().getSerializableExtra("selectednewid"));

        getSupportActionBar().setTitle("Post Commment");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        getSupportActionBar().setHomeAsUpIndicator(android.R.drawable.ic_media_previous);
    }


    public void toResultClicked(View v){
        postComment task = new postComment();
        // check for empty entries for name or comments
        if (Objects.equals(name.getText().toString(), "") || Objects.equals(text.getText().toString(), "")) {
            prgDialog = new ProgressDialog(PostCommentActivity.this);
            prgDialog.setTitle("Error!");
            prgDialog.setMessage("Make sure that you entered your name and comments, click anywhere to close the error message");
            prgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            prgDialog.show();
        }
        else {
            task.execute("http://10.3.0.14:8080/newsapp/savecomment",
                    name.getText().toString(),
                    text.getText().toString(),
                    news_id
            );

            // clicked news to pass to CommentActivity
            Intent i = new Intent(this, CommentActivity.class);
            setResult(RESULT_OK,i);
            finish();
        }
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == android.R.id.home){
            finish();
        }
        return true;
    }

    class postComment extends AsyncTask<String,Void,String> {

        @Override
        protected String doInBackground(String... strings) {

            StringBuilder strBuilder = new StringBuilder();
            String urlStr = strings[0];
            String name = strings[1];
            String text = strings[2];
            String news_id = strings[3];

            JSONObject obj = new JSONObject(); // create a JSON object for name and comments
            try {
                obj.put("name",name);
                obj.put("text",text);
                obj.put("news_id",news_id);
            } catch (JSONException e) {
                e.printStackTrace();
            }

            try {
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                conn.setDoInput(true);
                conn.setDoOutput(true);
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type","application/json");
                conn.connect();

                DataOutputStream out = new DataOutputStream(conn.getOutputStream());
                out.writeBytes(obj.toString());

                if(conn.getResponseCode()==HttpURLConnection.HTTP_OK){ // if successful
                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                    String line ="";

                    while((line = reader.readLine())!=null){
                        strBuilder.append(line);
                    }
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return strBuilder.toString();
        }

        @Override
        protected void onPostExecute(String s) {

            try {
                JSONObject inputObj = new JSONObject(s);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
}


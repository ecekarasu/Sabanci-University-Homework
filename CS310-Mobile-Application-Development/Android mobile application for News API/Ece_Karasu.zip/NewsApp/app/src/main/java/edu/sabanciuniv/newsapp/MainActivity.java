package edu.sabanciuniv.newsapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;

import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager2 viewPager2;
    ViewPagerAdapter viewPagerAdapter;

    RecyclerView newsRecView;

    List<NewsItem> data; // data to be displayed
    List<NewsItem> data_orig; // data that stores all the news
    List<NewsItem> data_econ; // data that stores all the news with category economics
    List<NewsItem> data_sports; // data that stores all the news with category sports
    List<NewsItem> data_politics; // data that stores all the news with category politics
    ProgressDialog prgDialog;
    NewsAdapter adp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        data = new ArrayList<>();
        data_orig = new ArrayList<>();
        data_econ = new ArrayList<>();
        data_sports = new ArrayList<>();
        data_politics = new ArrayList<>();
        newsRecView = findViewById(R.id.commentsrec);
        adp = new NewsAdapter(data, this, new NewsAdapter.NewsItemClickListener() {
            @Override
            public void newItemClicked(NewsItem selectedNewsItem) {
                // clicked news to pass to NewsDetailActivity
                Intent i = new Intent(MainActivity.this,NewsDetailActivity.class);
                i.putExtra("selectednew", selectedNewsItem);
                startActivity(i);
            }

        });
        newsRecView.setLayoutManager(new LinearLayoutManager(this));
        newsRecView.setAdapter(adp);

        tabLayout = findViewById(R.id.tab_layout);
        viewPager2 = findViewById(R.id.view_pager);
        viewPagerAdapter = new ViewPagerAdapter(this);
        viewPager2.setAdapter(viewPagerAdapter);


        GetAllNews tsk = new GetAllNews();
        tsk.execute("http://10.3.0.14:8080/newsapp/getall");

        getSupportActionBar().setTitle("  CS310 News");
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setIcon(R.drawable.newspaper);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                viewPager2.setCurrentItem(tab.getPosition()); // changes tab
                if(tab.getPosition() == 0) { // if economics clicked
                    data.clear();
                    data.addAll(data_econ);
                    adp.notifyDataSetChanged();
                }
                else if(tab.getPosition() == 1){ // if sports clicked
                    data.clear();
                    data.addAll(data_sports);
                    adp.notifyDataSetChanged();
                }
                else if(tab.getPosition() == 2){ // if politics clicked
                    data.clear();
                    data.addAll(data_politics);
                    adp.notifyDataSetChanged();

                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        viewPager2.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                tabLayout.getTabAt(position).select();
            }
        });
    }

    class GetAllNews extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute() {
            prgDialog = new ProgressDialog(MainActivity.this);
            prgDialog.setTitle("Loading...");
            prgDialog.setMessage("Please wait...");
            prgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            prgDialog.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            String urlStr = strings[0];
            StringBuilder buffer = new StringBuilder();
            try {
                URL url = new URL(urlStr);
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                String line ="";
                while((line=reader.readLine())!=null){
                    buffer.append(line);
                }
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return buffer.toString();
        }

        @Override
        protected void onPostExecute(String s) {
            data.clear();
            try {
                JSONObject obj = new JSONObject(s);

                if( obj.getInt("serviceMessageCode") == 1){
                    JSONArray arr =  obj.getJSONArray("items");

                    // this loop is to create data_orig
                    for (int i = 0; i < arr.length(); i++){
                        JSONObject current = (JSONObject) arr.get(i);
                        String date_str = current.getString("date");
                        DateFormat format = null;
                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
                            format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.ENGLISH);
                        }
                        Date objDate = format.parse(date_str);

                        NewsItem item = new NewsItem(current.getInt("id"),
                                current.getString("title"),
                                current.getString("text"),
                                current.getString("image"),
                                objDate,
                                current.getString("categoryName")
                        );

                        if (Objects.equals(item.getCategory(), "Economics")) {
                            data_econ.add(item);
                            data.add(item);
                        }
                        else if (Objects.equals(item.getCategory(), "Sports")) {
                            data_sports.add(item);
                        }
                        else if (Objects.equals(item.getCategory(), "Politics")) {
                            data_politics.add(item);
                        }
                        data_orig.add(item);

                    }
                }
                adp.notifyDataSetChanged();

            } catch (JSONException e) {
                Log.e("DEV",e.getMessage());

            } catch (ParseException e) {
                e.printStackTrace();
            }
            prgDialog.dismiss();
        }
    }
}
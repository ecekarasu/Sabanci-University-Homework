package edu.sabanciuniv.newsapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.List;

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.NewsViewHolder>{

    List<NewsItem> newsItems;
    Context context;
    NewsItemClickListener listener;

    // constructor
    public NewsAdapter(List<NewsItem> newsItems, Context context, NewsItemClickListener listener) {
        this.newsItems = newsItems;
        this.context = context;
        this.listener = listener;
    }

    @NonNull
    @Override
    public NewsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.news_row_layout,parent,false);
        return new NewsViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull NewsViewHolder holder, @SuppressLint("RecyclerView") final int position) {

        holder.txtDate.setText(new SimpleDateFormat("dd/MM/yyy").format(newsItems.get(position).getNewsDate()));
        holder.txtTitle.setText(newsItems.get(position).getTitle());

        holder.root.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.newItemClicked(newsItems.get(position));
            }
        });

        if(newsItems.get(position).getBitmap() == null){
            new ImageDownload(holder.imgNews).execute(newsItems.get(position));
        }else{
            holder.imgNews.setImageBitmap(newsItems.get(position).getBitmap());
        }
    }

    @Override
    public int getItemCount() {
        return newsItems.size();
    }

    public interface NewsItemClickListener{
        public void newItemClicked(NewsItem selectedNewsItem);
    }

    class NewsViewHolder extends RecyclerView.ViewHolder{

        ImageView imgNews;
        TextView txtTitle;
        TextView txtDate;
        ConstraintLayout root;

        public NewsViewHolder(@NonNull View itemView) {
            super(itemView);

            imgNews = itemView.findViewById(R.id.imgnews);
            txtTitle = itemView.findViewById(R.id.txtlistname);
            txtDate = itemView.findViewById(R.id.txtlistmessage);
            root = itemView.findViewById(R.id.container);

        }
    }

    // this class to download the news images
    class ImageDownload extends AsyncTask<NewsItem, Void, Bitmap> {

        ImageView imgView;

        public ImageDownload(ImageView imgView){
            this.imgView = imgView;
        }

        @Override
        protected Bitmap doInBackground(NewsItem... newsItems) {

            NewsItem current = newsItems[0];
            Bitmap bitmap = null;

            try {
                URL url = new URL(current.getImagePath());
                InputStream is = new BufferedInputStream(url.openStream());

                bitmap = BitmapFactory.decodeStream(is);
                current.setBitmap(bitmap);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return bitmap;
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {

            imgView.setImageBitmap(bitmap);
        }
    }
}